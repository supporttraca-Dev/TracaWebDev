// ============================================================
//  TRACA — Auth par Page Login + Cookie Session
//  - Ferme l'onglet = déconnecté (session cookie sans max-age)
//  - Variable d'env : SITE_PASSWORD (dashboard Netlify)
// ============================================================

const LOGIN_URL    = "/login.html";
const AUTH_ROUTE   = "/__auth";
const COOKIE_NAME  = "traca_session";
const COOKIE_VALUE = "granted";

// Réponse de redirection vers la page login
const redirectToLogin = (error = false) =>
  new Response(null, {
    status: 302,
    headers: {
      "Location": error ? `${LOGIN_URL}?error=1` : LOGIN_URL,
    },
  });

// Lecture d'un cookie depuis la requête
const getCookie = (request, name) => {
  const header = request.headers.get("Cookie") || "";
  const match  = header.match(new RegExp(`(?:^|;\\s*)${name}=([^;]*)`));
  return match ? match[1] : null;
};

export default async function auth(request, context) {
  const url = new URL(request.url);

  // ── 1. Ne pas protéger la page login elle-même ni ses assets
  if (url.pathname === LOGIN_URL || url.pathname === "/login.html") {
    return context.next();
  }

  // ── 2. Traitement du formulaire POST /__auth
  if (url.pathname === AUTH_ROUTE && request.method === "POST") {
    try {
      const body     = await request.formData();
      const password = body.get("password") || "";
      const redirect = body.get("redirect")  || "/";

      let correctPassword = "Y6Dcpibe8hew2qmr"; // fallback
      try {
        const envPass = Netlify.env.get("SITE_PASSWORD");
        if (envPass) correctPassword = envPass;
      } catch (e) { /* Netlify.env indisponible, on use le fallback */ }

      if (password !== correctPassword) {
        return redirectToLogin(true); // erreur → retour login avec ?error=1
      }

      // ✅ Mot de passe correct → poser le cookie de SESSION (sans Max-Age ni Expires = ferme l'onglet = terminé)
      const destination = redirect.startsWith("/") ? redirect : "/";
      return new Response(null, {
        status: 302,
        headers: {
          "Location": destination,
          "Set-Cookie": `${COOKIE_NAME}=${COOKIE_VALUE}; Path=/; HttpOnly; SameSite=Lax`,
          // Pas de Max-Age → cookie de session (disparaît à la fermeture du navigateur)
        },
      });

    } catch (e) {
      return redirectToLogin(true);
    }
  }

  // ── 3. Pour toutes les autres routes → vérifier le cookie
  const session = getCookie(request, COOKIE_NAME);
  if (session === COOKIE_VALUE) {
    return context.next(); // ✅ Authentifié
  }

  // ── 4. Pas de cookie → rediriger vers la page login
  return redirectToLogin(false);
}

export const config = { path: "/*" };
